package com.example.exam_reprise.exo_oiseau.entite;
public class Oiseau {
    private int id;
    private String nom;
    private String description;
    private String img_name;
    private int nombreVue;
    public Oiseau() {
    }
    public Oiseau(int id, String nom, String description, String img_name) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.img_name = img_name;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getImg_name() {
        return img_name;
    }
    public void setImg_name(String img_name) {
        this.img_name = img_name;
    }
    public int getNombreVue() {
        return nombreVue;
    }
    public void setNombreVue(int nombreVue) {
        this.nombreVue = nombreVue;
    }
}
