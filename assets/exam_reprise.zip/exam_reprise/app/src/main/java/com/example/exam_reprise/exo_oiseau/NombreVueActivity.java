package com.example.exam_reprise.exo_oiseau;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.example.exam_reprise.R;
import com.example.exam_reprise.exo_oiseau.adapter.OiseauListViewAdapter;
import com.example.exam_reprise.exo_oiseau.entite.Oiseau;
import com.example.exam_reprise.exo_oiseau.manager.OiseauViewManager;

import java.util.ArrayList;
public class NombreVueActivity extends Activity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nombre_vue);
        listView = findViewById(R.id.lv_nombre_vue);
        ArrayList<Oiseau> oiseaus = OiseauViewManager.getListOiseau(this);
        if(oiseaus != null){
        OiseauListViewAdapter oiseauListViewAdapter = new OiseauListViewAdapter(this, R.layout.oiseau_listview, oiseaus);
        listView.setAdapter(oiseauListViewAdapter);
        }else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Pas d'oiseau vue pour le moment");
            builder.setPositiveButton("Quitter", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            builder.show();
        }

    }

    public void handleBtnRetour(View view){
        finish();
    }
}