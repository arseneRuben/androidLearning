package com.example.exam_reprise.exo_oiseau;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.exam_reprise.R;
import com.example.exam_reprise.exo_oiseau.adapter.OiseauGridViewAdapter;
import com.example.exam_reprise.exo_oiseau.entite.Oiseau;
import com.example.exam_reprise.exo_oiseau.manager.OiseauManager;
import com.example.exam_reprise.exo_oiseau.service.ConnexionExoOiseau;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
public class OiseauActivity extends Activity {
    GridView gridView;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        setContentView(com.example.exam_reprise.R.layout.activity_oiseau);
        gridView = findViewById(R.id.gd_oiseau);
        if (ConnexionExoOiseau.getVersion() == 0)
            ConnexionExoOiseau.copyBdFromAssets(this);
        ArrayList<Oiseau> oiseaux = OiseauManager.getAll(this);
        OiseauGridViewAdapter oiseauAdapter = new OiseauGridViewAdapter(this, R.layout.oiseau_gridview, oiseaux);
        gridView.setAdapter(oiseauAdapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Oiseau o = (Oiseau) adapterView.getItemAtPosition(i);
                Log.d("debugApp", o.getNom());
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                LinearLayout ll = (LinearLayout) getLayoutInflater().inflate(R.layout.ad_oiseau_description, null);
                ImageView img = ll.findViewById(R.id.img_oiseau_ad);
                TextView tvNom = ll.findViewById(R.id.tv_nom_oiseau_ad);
                TextView tvDecription = ll.findViewById(R.id.tv_oiseau_description_ad);
                AssetManager assetManager = context.getAssets();
                tvNom.setText(o.getNom());
                tvDecription.setText(o.getDescription());
                try {
                    InputStream in = assetManager.open(o.getImg_name());
                    img.setImageDrawable(Drawable.createFromStream(in, o.getNom()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                builder.setView(ll);
                builder.setNeutralButton("close", null);
                builder.show();
            }
        });
    }
    public void handleBtnNbView(View view) {
        startActivity(new Intent(context, NombreVueActivity.class));
    }
}