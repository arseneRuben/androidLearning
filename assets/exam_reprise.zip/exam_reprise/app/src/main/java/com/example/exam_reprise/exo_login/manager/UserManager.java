package com.example.exam_reprise.exo_login.manager;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.exam_reprise.exo_login.entitie.User;
import com.example.exam_reprise.exo_login.service.ConnexionExoLogin;
public class UserManager {
    @SuppressLint("Range")
    public static User login(Context context, User uToTest) {
        User retour = null;
        String query = "select * from user where login like ? and password like ? ;";
        SQLiteDatabase bd = ConnexionExoLogin.getBd(context);
        Cursor cursor = bd.rawQuery(query, new String[]{uToTest.getLogin(), uToTest.getPassword()});
        if (cursor.moveToNext()) {
            retour = new User();
            retour.setId(cursor.getInt(cursor.getColumnIndex("id")));
            retour.setNom(cursor.getString(cursor.getColumnIndex("nom")));
            retour.setPrenom(cursor.getString(cursor.getColumnIndex("prenom")));
        }
        ConnexionExoLogin.close();
        return retour;
    }
    public static boolean insert(Context context, User uToInsert) {
        ContentValues toAdd = new ContentValues();
        toAdd.put("nom", uToInsert.getNom());
        toAdd.put("prenom", uToInsert.getPrenom());
        toAdd.put("login", uToInsert.getLogin());
        toAdd.put("password", uToInsert.getPassword());
        long newId = ConnexionExoLogin.getBd(context).insert("user",null, toAdd);
        ConnexionExoLogin.close();
        return newId != -1;
    }
}
