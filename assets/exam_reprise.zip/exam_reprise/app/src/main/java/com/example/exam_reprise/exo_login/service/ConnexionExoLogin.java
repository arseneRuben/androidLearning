package com.example.exam_reprise.exo_login.service;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.exam_reprise.exo_login.sqlHelper.ExoLoginHelper;
public class ConnexionExoLogin {
    private static final String nomBd = "exoLogin";
    private static int version = 1;
    private static SQLiteDatabase instanceBd;
    public static SQLiteDatabase getBd(Context context) {
        ExoLoginHelper exoLoginHelper = new ExoLoginHelper(context, nomBd, null, version);
        instanceBd = exoLoginHelper.getWritableDatabase();
        return instanceBd;
    }
    public static void close() {
        instanceBd.close();
    }
}
