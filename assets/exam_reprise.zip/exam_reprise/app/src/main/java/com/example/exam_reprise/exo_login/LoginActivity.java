package com.example.exam_reprise.exo_login;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.exam_reprise.R;
import com.example.exam_reprise.exo_login.entitie.User;
import com.example.exam_reprise.exo_login.manager.UserManager;
public class LoginActivity extends Activity {
    EditText edLogin, edPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.exam_reprise.R.layout.activity_login);
        edLogin = findViewById(R.id.ed_login);
        edPassword = findViewById(R.id.ed_pwd);
    }
    public void handleBtnConnexion(View view) {
        User uToTest = new User();
        uToTest.setLogin(edLogin.getText().toString());
        uToTest.setPassword(edPassword.getText().toString());
        User retour = UserManager.login(this, uToTest);
        if (retour != null) {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("nom", retour.getNom());
            editor.putString("prenom", retour.getPrenom());
            editor.putInt("id", retour.getId());
            editor.commit();
            startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            finish();
        } else {
            Toast.makeText(getApplicationContext(), "login or password incorrect", Toast.LENGTH_SHORT).show();
        }
    }
    public void handleBtnInscription(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(R.layout.ad_inscription_layout);
        builder.setTitle("Inscription User");
        builder.setPositiveButton("Ajouter", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                AlertDialog dialog = (AlertDialog) dialogInterface;
                User user = new User();
                user.setNom(((EditText) dialog.findViewById(R.id.ed_nom_ad)).getText().toString());
                user.setPrenom(((EditText) dialog.findViewById(R.id.ed_prenom_ad)).getText().toString());
                user.setLogin(((EditText) dialog.findViewById(R.id.ed_login_ad)).getText().toString());
                user.setPassword(((EditText) dialog.findViewById(R.id.ed_password_ad)).getText().toString());
                boolean isInsert = UserManager.insert(getApplicationContext(), user);
                dialog.dismiss();
                if(isInsert) {
                    Toast.makeText(getApplicationContext(),"Utilisateur ajouté", Toast.LENGTH_SHORT ).show();
                }
            }
        });
        builder.setNegativeButton("Annuler", null);
        builder.show();
    }
}