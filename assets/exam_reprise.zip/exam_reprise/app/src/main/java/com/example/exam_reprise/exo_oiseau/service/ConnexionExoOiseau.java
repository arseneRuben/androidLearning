package com.example.exam_reprise.exo_oiseau.service;
import android.content.Context;
import android.content.res.AssetManager;
import android.database.sqlite.SQLiteDatabase;

import com.example.exam_reprise.exo_login.sqlHelper.ExoLoginHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
public class ConnexionExoOiseau {
    private static final String nomBd = "reprise.db";
    private static int version = 0;
    private static SQLiteDatabase instanceBd;
    public static SQLiteDatabase getBd(Context context) {
        ExoLoginHelper exoLoginHelper = new ExoLoginHelper(context, nomBd, null, version);
        instanceBd = exoLoginHelper.getWritableDatabase();
        return instanceBd;
    }
    public static void close() {
        instanceBd.close();
    }
    public static void copyBdFromAssets(Context context) {
        version = 1;
        File bdApp = context.getDatabasePath(nomBd);
        AssetManager assetManager = context.getAssets();
        try {
            InputStream in = assetManager.open(nomBd);
            FileOutputStream out = new FileOutputStream(bdApp);
            byte[] buffer = new byte[256];
            while (in.read(buffer) != -1) {
                out.write(buffer);
                buffer = new byte[256];
            }
            in.close();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static int getVersion() {
        return version;
    }
}
