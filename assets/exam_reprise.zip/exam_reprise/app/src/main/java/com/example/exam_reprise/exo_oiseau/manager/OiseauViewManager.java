package com.example.exam_reprise.exo_oiseau.manager;
import android.content.Context;

import com.example.exam_reprise.exo_oiseau.entite.Oiseau;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class OiseauViewManager {

    private static HashMap<Integer, Integer> oiseauVues = null;

    public static void add(int idOiseau){
        if(oiseauVues == null)
            oiseauVues = new HashMap<>();
        if(oiseauVues.containsKey(idOiseau)){
            oiseauVues.put(idOiseau, oiseauVues.get(idOiseau)+1);
        }else{
            oiseauVues.put(idOiseau, 1);
        }
    }

    public static int get(int idOiseau){
        int nb = 0;
        if(oiseauVues != null)
            nb = oiseauVues.get(idOiseau);
        return nb;
    }

    public static ArrayList<Oiseau> getListOiseau(Context context){
        ArrayList<Oiseau> retour = null;
        if(oiseauVues != null && !oiseauVues.isEmpty()){
            retour = new ArrayList<>();
            for (Map.Entry<Integer, Integer> ligne : oiseauVues.entrySet()){
                Oiseau oiseauToAdd = OiseauManager.getById(context, ligne.getKey());
                oiseauToAdd.setNombreVue(ligne.getValue());
                retour.add(oiseauToAdd);
            }
        }
        return retour;
    }
}
