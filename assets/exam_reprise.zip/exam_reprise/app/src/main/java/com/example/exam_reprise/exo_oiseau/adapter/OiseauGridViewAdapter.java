package com.example.exam_reprise.exo_oiseau.adapter;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.exam_reprise.R;
import com.example.exam_reprise.exo_oiseau.entite.Oiseau;
import com.example.exam_reprise.exo_oiseau.manager.OiseauViewManager;

import java.io.Console;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
public class OiseauGridViewAdapter extends ArrayAdapter<Oiseau> implements View.OnClickListener {
    int idUi;
    public OiseauGridViewAdapter(@NonNull Context context, int resource, @NonNull List<Oiseau> objects) {
        super(context, resource, objects);
        idUi = resource;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Oiseau oiseau = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(idUi, null);
            ImageView imgAdd = convertView.findViewById(R.id.img_add);
            imgAdd.setTag(oiseau.getId());
            imgAdd.setOnClickListener(this);
        }
        ImageView img = convertView.findViewById(R.id.img_oiseau);
        TextView tv = convertView.findViewById(R.id.tv_oiseau);
        tv.setText(oiseau.getNom());
        AssetManager assetManager = getContext().getAssets();
        try {
            InputStream in = assetManager.open(oiseau.getImg_name());
            img.setImageDrawable(Drawable.createFromStream(in, "oiseau"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return convertView;
    }
    @Override
    public void onClick(View view) {
//        Log.d("debugApp", "hello" + view.getTag());
        OiseauViewManager.add((int) view.getTag());
        Toast.makeText(getContext(), "nb Vue : " + OiseauViewManager.get((int) view.getTag()), Toast.LENGTH_SHORT).show();
    }
}
