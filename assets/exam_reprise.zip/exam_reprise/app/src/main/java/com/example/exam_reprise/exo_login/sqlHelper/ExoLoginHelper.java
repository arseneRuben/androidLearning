package com.example.exam_reprise.exo_login.sqlHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
public class ExoLoginHelper extends SQLiteOpenHelper {

    public ExoLoginHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table user(" +
                " id integer primary key autoincrement," +
                " nom text," +
                " prenom text," +
                " login text," +
                "password text);");
        sqLiteDatabase.execSQL("insert into user (nom, prenom, login, password) values ('ExamTestNom','ExamTestPrenom', 'b','c')," +
                "('main','user', 'admin','abc');");
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String creation = "create table user( id integer primary key autoincrement, nom text, prenom text, login text, password text);";
        String insertion = "insert into user(nom, prenom, login, password) values ('ExamTestNom','ExamTestPrenom', 'b','c'), ('main','user', 'admin','abc');";
        sqLiteDatabase.execSQL(creation);
        sqLiteDatabase.execSQL(insertion);
    }
}
