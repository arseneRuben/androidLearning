package com.example.exam_reprise.exo_oiseau.adapter;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.exam_reprise.R;
import com.example.exam_reprise.exo_oiseau.entite.Oiseau;

import java.io.IOException;
import java.util.List;
public class OiseauListViewAdapter extends ArrayAdapter<Oiseau> {
    int uiId;
    public OiseauListViewAdapter(@NonNull Context context, int resource, @NonNull List<Oiseau> objects) {
        super(context, resource, objects);
        uiId = resource;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Oiseau oiseau = getItem(position);
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(uiId, null);
        }
        ImageView img = convertView.findViewById(R.id.lv_img_oiseau);
        TextView tvNom = convertView.findViewById(R.id.lv_tv_nom);
        TextView tvQte = convertView.findViewById(R.id.lv_tv_qte);
        tvNom.setText(oiseau.getNom());
        tvQte.setText(""+oiseau.getNombreVue());
        try {
            img.setImageDrawable(Drawable.createFromStream(getContext().getAssets().open(oiseau.getImg_name()),"oiseau"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return convertView;
    }
}
