package com.example.exam_reprise.exo_oiseau.manager;
import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.exam_reprise.exo_oiseau.entite.Oiseau;
import com.example.exam_reprise.exo_oiseau.service.ConnexionExoOiseau;

import java.util.ArrayList;
public class OiseauManager {
    @SuppressLint("Range")
    public static ArrayList<Oiseau> getAll(Context context) {
        ArrayList<Oiseau> retour = null;
        String query = "select id, nom, description, img_name from oiseau";
        SQLiteDatabase bd = ConnexionExoOiseau.getBd(context);
        Cursor cursor = bd.rawQuery(query, null);
        if (cursor.isBeforeFirst()) {
            retour = new ArrayList<>();
            while (cursor.moveToNext()) {
                retour.add(new Oiseau(
                                cursor.getInt(cursor.getColumnIndex("id")),
                                cursor.getString(cursor.getColumnIndex("nom")),
                                cursor.getString(cursor.getColumnIndex("description")),
                                cursor.getString(cursor.getColumnIndex("img_name"))
                        )
                );
            }
        }
        bd.close();
        return retour;
    }
    @SuppressLint("Range")
    public static Oiseau getById(Context context, int id) {
        Oiseau retour = null;
        String query = "select id, nom, description, img_name from oiseau where id = ?";
        SQLiteDatabase bd = ConnexionExoOiseau.getBd(context);
        Cursor cursor = bd.rawQuery(query, new String[]{String.valueOf(id)});
        if (cursor.moveToNext()) {
            retour = new Oiseau(
                    cursor.getInt(cursor.getColumnIndex("id")),
                    cursor.getString(cursor.getColumnIndex("nom")),
                    cursor.getString(cursor.getColumnIndex("description")),
                    cursor.getString(cursor.getColumnIndex("img_name"))
            );
        }
        bd.close();
        return retour;
    }
}
